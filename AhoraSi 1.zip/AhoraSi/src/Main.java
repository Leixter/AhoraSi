import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Coloreado de Grafo Interactivo");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(900, 900);

            InteractiveGraphPanel panel = new InteractiveGraphPanel();
            frame.add(panel);

            frame.setVisible(true);
        });
    }
}
