import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class InteractiveGraphPanel extends JPanel {
    private final Graph graph;
    private final java.util.List<Point> nodePositions = new ArrayList<>();
    private int selectedNode = -1;

    public InteractiveGraphPanel() {
        this.graph = new Graph(20); // máximo 20 nodos
        setPreferredSize(new Dimension(800, 800));
        setLayout(null);

        JButton colorButton = new JButton("Colorear");
        colorButton.setBounds(720, 20, 120, 30);
        add(colorButton);

        colorButton.addActionListener(e -> {
            GraphColoring.greedyColor(graph);
            repaint();
        });

        addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                Point click = e.getPoint();
                int clickedNode = getNodeAt(click);

                if (SwingUtilities.isLeftMouseButton(e)) {
                    if (clickedNode == -1) {
                        nodePositions.add(click);
                        repaint();
                    } else {
                        if (selectedNode == -1) {
                            selectedNode = clickedNode;
                        } else {
                            graph.addEdge(selectedNode, clickedNode);
                            selectedNode = -1;
                            repaint();
                        }
                    }
                }
            }
        });
    }

    private int getNodeAt(Point p) {
        for (int i = 0; i < nodePositions.size(); i++) {
            Point node = nodePositions.get(i);
            if (p.distance(node) < 20) return i;
        }
        return -1;
    }

    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Color[] palette = {Color.RED, Color.GREEN, Color.BLUE, Color.ORANGE, Color.MAGENTA, Color.CYAN, Color.YELLOW};

        for (int i = 0; i < nodePositions.size(); i++) {
            for (int j : graph.getAdj(i)) {
                if (i < j && j < nodePositions.size()) {
                    g.setColor(Color.BLACK);
                    g.drawLine(nodePositions.get(i).x, nodePositions.get(i).y, nodePositions.get(j).x, nodePositions.get(j).y);
                }
            }
        }

        for (int i = 0; i < nodePositions.size(); i++) {
            int color = graph.getColor(i);
            g.setColor(color == -1 ? Color.LIGHT_GRAY : palette[color % palette.length]);
            g.fillOval(nodePositions.get(i).x - 20, nodePositions.get(i).y - 20, 40, 40);
            g.setColor(Color.BLACK);
            g.drawOval(nodePositions.get(i).x - 20, nodePositions.get(i).y - 20, 40, 40);
            g.drawString(String.valueOf(i), nodePositions.get(i).x - 5, nodePositions.get(i).y + 5);
        }

        if (selectedNode != -1) {
            Point selected = nodePositions.get(selectedNode);
            g.setColor(Color.RED);
            g.drawOval(selected.x - 25, selected.y - 25, 50, 50);
        }
    }

}

