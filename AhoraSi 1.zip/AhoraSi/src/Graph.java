import java.util.*;

public class Graph {
    private final int vertices;
    private final List<List<Integer>> adjList;
    private final int[] colors;

    public Graph(int vertices) {
        this.vertices = vertices;
        this.colors = new int[vertices];
        Arrays.fill(colors, -1);
        adjList = new ArrayList<>();
        for (int i = 0; i < vertices; i++) {
            adjList.add(new ArrayList<>());
        }
    }

    public void addEdge(int u, int v) {
        if (!adjList.get(u).contains(v)) {
            adjList.get(u).add(v);
            adjList.get(v).add(u);
        }
    }

    public List<Integer> getAdj(int v) {
        return adjList.get(v);
    }

    public int getVertices() {
        return vertices;
    }

    public int[] getColors() {
        return colors;
    }

    public void setColor(int vertex, int color) {
        colors[vertex] = color;
    }

    public int getColor(int vertex) {
        return colors[vertex];
    }
}

