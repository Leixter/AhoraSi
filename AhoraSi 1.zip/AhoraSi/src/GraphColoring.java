public class GraphColoring {
    public static void greedyColor(Graph graph) {
        int V = graph.getVertices();
        int[] result = graph.getColors();
        result[0] = 0;

        boolean[] available = new boolean[V];

        for (int u = 1; u < V; u++) {
            for (int neighbor : graph.getAdj(u)) {
                int color = graph.getColor(neighbor);
                if (color != -1) {
                    available[color] = true;
                }
            }

            int cr;
            for (cr = 0; cr < V; cr++) {
                if (!available[cr]) break;
            }

            graph.setColor(u, cr);

            for (int neighbor : graph.getAdj(u)) {
                int color = graph.getColor(neighbor);
                if (color != -1) {
                    available[color] = false;
                }
            }
        }
    }
}

